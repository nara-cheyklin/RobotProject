import sys
import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose


class TurtleLetterController(Node):
    def __init__(self, letter):
        super().__init__('turtle_letter_controller')
        self.letter = letter.upper()

        # ROS interfaces
        self.pose = None
        self.sub = self.create_subscription(Pose, '/turtle1/pose', self.pose_callback, 10)
        self.pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.timer = self.create_timer(0.1, self.control_loop)

        # Waypoints for letters
        self.targets = self.get_waypoints(self.letter)
        self.current_target_index = 0
        self.state = "align"  # "align" or "move"

        # Control gains
        self.k_linear = 1.5
        self.k_angular = 4.0
        self.dist_tol = 0.05
        self.ang_tol = 0.05

    def get_waypoints(self, letter):
        """Define waypoints for each letter (P and L)."""
        if letter == "P":
            return [
                (5.5, 8.0),  # vertical up
                (7.0, 8.0),  # right
                (7.0, 6.5),  # down
                (5.5, 6.5)   # left
            ]
        elif letter == "L":
            return [
                (5.5, 3.0),  # straight down
                (8.0, 3.0)   # then right
            ]
        else:
            self.get_logger().error("Unsupported letter, defaulting to L")
            return [(5.5, 3.0), (8.0, 3.0)]

    def pose_callback(self, msg):
        self.pose = msg

    def control_loop(self):
        if self.pose is None or self.current_target_index >= len(self.targets):
            return

        target_x, target_y = self.targets[self.current_target_index]
        dx = target_x - self.pose.x
        dy = target_y - self.pose.y
        distance = math.sqrt(dx**2 + dy**2)

        angle_to_goal = math.atan2(dy, dx)
        angle_error = angle_to_goal - self.pose.theta
        # Normalize
        angle_error = math.atan2(math.sin(angle_error), math.cos(angle_error))

        twist = Twist()

        if self.state == "align":
            if abs(angle_error) > self.ang_tol:
                twist.angular.z = self.k_angular * angle_error
            else:
                # alignment done → switch to moving
                self.state = "move"

        elif self.state == "move":
            if distance > self.dist_tol:
                twist.linear.x = self.k_linear * distance
                twist.angular.z = self.k_angular * angle_error
            else:
                # reached target → stop and go to next
                self.current_target_index += 1
                self.state = "align"
                twist.linear.x = 0.0
                twist.angular.z = 0.0

        self.pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    if len(sys.argv) < 2:
        print("Usage: ros2 run <pkg> draw_letters_pose <P|L>")
        return

    letter = sys.argv[1]
    node = TurtleLetterController(letter)
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
